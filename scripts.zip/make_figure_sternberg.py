import emcee
import scipy.optimize as op
import numpy as np
import matplotlib.pyplot as plt

path = 'I:/D\Research/KIC8462852 comet/Sonneberg/data_release_v3/'
path = ''

_ = np.genfromtxt(path + 'sternberg_all.csv', unpack=True, delimiter=',')
x = _[0]
y = _[1]
yerr = _[2]

_ = np.genfromtxt(path + 'sternberg_10cm.csv', unpack=True, delimiter=',')
x_10cm = _[0]
y_10cm = _[1]

_ = np.genfromtxt(path + 'sternberg_16cm.csv', unpack=True, delimiter=',')
x_16cm = _[0]
y_16cm = _[1]

_ = np.genfromtxt(path + 'sternberg_40cm.csv', unpack=True, delimiter=',')
x_40cm = _[0]
y_40cm = _[1]


# Least-squares regression
xl = np.array([1890, 2000])
A = np.vstack((np.ones_like(x), x)).T
C = np.diag(yerr * yerr)
cov = np.linalg.inv(np.dot(A.T, np.linalg.solve(C, A)))
b_ls, m_ls = np.dot(cov, np.dot(A.T, np.linalg.solve(C, y)))
print("""Least-squares results:
    m = {0} ± {1}
    b = {2} ± {3}
""".format(m_ls, np.sqrt(cov[1, 1]), b_ls, np.sqrt(cov[0, 0])))


fig, ax1 = plt.subplots(1, 1, figsize=[8,5], sharex=False, sharey=False)
ax1.tick_params(direction='out')
#ax1.fill_between(xval, pc[0]-10, pc[2]-10, alpha=0.5, color='blue')
plt.scatter(x_10cm, y_10cm, color='red', alpha=0.5, marker='s')
plt.scatter(x_16cm, y_16cm, color='green', alpha=0.5, marker='^')
plt.scatter(x_40cm, y_40cm, color='blue', alpha=0.5)

ax1.annotate('40cm Astrograph', xy=(1970, 12.8),  color = 'blue')
ax1.annotate('9.7cm Steinheil', xy=(1890, 12.8),  color = 'red')
ax1.annotate('16cm Tessar', xy=(1940, 12.8),  color = 'green')

plt.plot(xl, m_ls*xl+b_ls, "--k")
text = 'LSQ ' + '{0:.3f}'.format(m_ls * 100) + '±' + '{0:.3f}'.format(np.sqrt(cov[1, 1]) * 100)
ax1.annotate('Sternberg pg', xy=(1885, 11.60))
ax1.annotate(text, xy=(1885, 11.70))
ax1.annotate('n=156', xy=(2005, 13.4))
ax1.set_xlim(1880, 2020)
ax1.set_ylim(11.5, 13.5)
ax1.set_xlabel('Year', fontweight='bold')
ax1.set_ylabel('pg mag', fontweight='bold')
fig.tight_layout()
plt.gca().invert_yaxis()
fig.savefig(path + 'fig_sternberg.pdf', bbox_inches = 'tight')
fig.show()
plt.show()
