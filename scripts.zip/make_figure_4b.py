import numpy
import matplotlib.pyplot as plt


data = numpy.genfromtxt('stata_output_pv.csv', unpack=True, skip_header=1, delimiter=',')
year = data[0]
mag_bin = data[1]
uncertainty = data[2]
date = data[7]
ly = data[8]
se = data[9]

ax = plt.axes()
plt.errorbar(year, mag_bin, yerr=uncertainty, xerr=2.5, fmt=".k")
plt.plot(date, ly, color = 'black')
plt.plot((0, 2000), (0, 0), 'k-')
plt.fill_between(date, ly+se, ly-se, alpha=0.5, color='red')
plt.annotate('pv', xy=((1932, 0.18)), size=18)
plt.xlim(1930, 2000) 
plt.ylim(-0.2, 0.2)
plt.gca().invert_yaxis()
plt.tick_params(axis='both', which='major', labelsize=16)
ax.tick_params(direction='out')
plt.xlabel('Year', fontsize=16, fontweight='bold')
plt.ylabel('differential magnitude', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig("fig_kernel_pv.pdf")
plt.show()
