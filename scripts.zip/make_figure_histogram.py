import numpy
import matplotlib.pyplot as plt


path = 'I:/D/Research/KIC8462852 comet/Sonneberg/data_release_v2/'
path = ''
file = 'dates.csv'
data = numpy.genfromtxt(path + file)
bins = numpy.arange(start = 1932, stop = 1995, step = 1)
n, bins, patches = plt.hist(data, bins=bins, facecolor='blue', alpha=0.75)
plt.xlabel('Year', fontweight='bold')
plt.ylabel('Number of plates', fontweight='bold')
plt.grid(True)
plt.savefig(path + 'fig_histo_years.pdf', bbox_inches = 'tight')
plt.show()
