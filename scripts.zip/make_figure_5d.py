import emcee
#import corner
import scipy.optimize as op
import numpy as np
import matplotlib.pyplot as plt

_ = np.genfromtxt('schaefer_bins_visual.csv', unpack=True, skip_header=1, delimiter=',')
x = _[0]
y = _[1] + 10
yerr = _[2]

# some useful functions

def lnlike(theta, x, y, yerr):
    m, b, lnf = theta
    model = m * x + b
    inv_sigma2 = 1.0/(yerr**2 + model**2*np.exp(2*lnf))
    return -0.5*(np.sum((y-model)**2*inv_sigma2 - np.log(inv_sigma2)))

def lnprior(theta):
    m, b, lnf = theta
    if -1. < m < 1. and 0.0 < b < 1000.0 and -10.0 < lnf < 10.0:
        return 0.0
    return -np.inf

def lnprob(theta, x, y, yerr):
    lp = lnprior(theta)
    if not np.isfinite(lp):
        return -np.inf
    return lp + lnlike(theta, x, y, yerr)

xl = np.array([1880, 2000])
A = np.vstack((np.ones_like(x), x)).T
C = np.diag(yerr * yerr)
cov = np.linalg.inv(np.dot(A.T, np.linalg.solve(C, A)))
b_ls, m_ls = np.dot(cov, np.dot(A.T, np.linalg.solve(C, y)))
print("""Least-squares results:
    m = {0} ± {1} 
    b = {2} ± {3} 
""".format(m_ls, np.sqrt(cov[1, 1]), b_ls, np.sqrt(cov[0, 0])))
plt.errorbar(x, y - 10, yerr=yerr, fmt=".k")

# Plot the least-squares result.
plt.plot(xl, m_ls*xl+b_ls - 10, "--k")
#plt.xlim(1890, 1990)
plt.xlabel("$x$")
plt.ylabel("$y$")
#plt.ylim(12.6,12.2)
plt.title('Least-squares fit')
plt.tight_layout()
plt.show()



nll = lambda *args: -lnlike(*args)
result = op.minimize(nll, [0.01,12,0.01], args=(x, y, yerr))
m_ml, b_ml, lnf_ml = result["x"]

xl = np.array([1880, 2000])
plt.errorbar(x, y - 10, yerr=yerr, fmt=".k")
plt.plot(xl, m_ml*xl+b_ml - 10, "k", lw=3, alpha=0.6)
plt.xlabel("$x$")
plt.ylabel("$y$")
plt.title('Maximum likelihood with uncertainty parameter')
plt.tight_layout()

plt.show()

# mcmc
ndim, nwalkers = 3, 300
pos = [result["x"] + 1e-4*np.random.randn(ndim) for i in range(nwalkers)]

sampler = emcee.EnsembleSampler(nwalkers, ndim, lnprob, args=(x, y, yerr))

# sample
s = sampler.run_mcmc(pos, 5000)
burnin = 100
samples = sampler.chain[:, burnin:, :].reshape((-1, ndim))


samples[:, 2] = np.exp(samples[:, 2])
m_mcmc, b_mcmc, f_mcmc = map(lambda v: (v[1], v[2]-v[1], v[1]-v[0]),
                             zip(*np.percentile(samples, [16, 50, 84],
                                                axis=0)))
print("""MCMC result:
    m = {0[0]} +{0[1]} -{0[2]} 
    b = {1[0]} +{1[1]} -{1[2]} 
    f = {2[0]} +{2[1]} -{2[2]} 
""".format(m_mcmc, b_mcmc, f_mcmc))

size=300000
xval = np.arange(1880,2000,1)
savearr = np.zeros([size,len(xval)])
for i, [m, b, lnf] in enumerate(samples[np.random.randint(len(samples), size=size)]):
    savearr[i] = m*xval+b

pc = np.percentile(savearr,[16, 50, 84], axis=0)

fig, ax1 = plt.subplots(1, 1, figsize=[8,5], sharex=False, sharey=False)
ax1.tick_params(direction='out')
ax1.fill_between(xval, pc[0] - 10, pc[2] - 10, alpha=0.5)
ax1.errorbar(x, y - 10, yerr=yerr, xerr=2.5, fmt=".k")
plt.plot(xl, m_ls*xl+b_ls - 10, "--k")
plt.plot(xl, m_ml*xl+b_ml - 10, "k", lw=3, alpha=0.6)
ax1.annotate('Schaefer (2016), by-eye measurements', xy=(1882, -0.35))
text = 'LSQ ' + '{0:.3f}'.format(m_ls * 100) + '±' + '{0:.3f}'.format(np.sqrt(cov[1, 1]) * 100)
ax1.annotate(text, xy=(1882, -0.30))
ax1.set_xlim(1880, 2000)
ax1.set_ylim(-0.4,+0.4)
ax1.set_xlabel('Year', fontweight='bold')
ax1.set_ylabel('differential magnitude', fontweight='bold')
fig.tight_layout()
plt.gca().invert_yaxis()
fig.savefig('schaefer_visual.pdf', bbox_inches = 'tight')
fig.show()
plt.show()
