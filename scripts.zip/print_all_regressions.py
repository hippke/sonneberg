import emcee
import scipy.optimize as op
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats


def lnlike(theta, x, y, yerr):
    m, b, lnf = theta
    model = m * x + b
    inv_sigma2 = 1.0/(yerr**2 + model**2*np.exp(2*lnf))
    return -0.5*(np.sum((y-model)**2*inv_sigma2 - np.log(inv_sigma2)))

def lnprior(theta):
    m, b, lnf = theta
    if -1. < m < 1. and 0.0 < b < 1000.0 and -10.0 < lnf < 10.0:
        return 0.0
    return -np.inf

def lnprob(theta, x, y, yerr):
    lp = lnprior(theta)
    if not np.isfinite(lp):
        return -np.inf
    return lp + lnlike(theta, x, y, yerr)


def make_regressions(x, y, yerr):
    slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)
    print('Least-squares without uncertainties:', 
        "{0:.3f}".format(slope * 100), 
        '+-'
        "{0:.3f}".format(std_err * 100))


    xl = np.array([1930, 2000])
    A = np.vstack((np.ones_like(x), x)).T
    C = np.diag(yerr * yerr)
    cov = np.linalg.inv(np.dot(A.T, np.linalg.solve(C, A)))
    b_ls, m_ls = np.dot(cov, np.dot(A.T, np.linalg.solve(C, y)))
    print('Least-squares with uncertainties:', 
        "{0:.3f}".format(m_ls * 100), 
        '+-'
        "{0:.3f}".format(np.sqrt(cov[1, 1]) * 100))


    nll = lambda *args: -lnlike(*args)
    result = op.minimize(nll, [0.01,0,0.01], args=(x, y, yerr))
    m_ml, b_ml, lnf_ml = result["x"]
    print('Maximum likelihood estimation with uncertainties:', 
        "{0:.3f}".format(m_ml * 100))


    # mcmc
    ndim, nwalkers = 3, 300
    pos = [result["x"] + 1e-4*np.random.randn(ndim) for i in range(nwalkers)]
    sampler = emcee.EnsembleSampler(nwalkers, ndim, lnprob, args=(x, y, yerr))
    s = sampler.run_mcmc(pos, 500)
    burnin = 100
    samples = sampler.chain[:, burnin:, :].reshape((-1, ndim))
    samples[:, 2] = np.exp(samples[:, 2])
    m_mcmc, b_mcmc, f_mcmc = map(lambda v: (v[1], v[2]-v[1], v[1]-v[0]),
                                 zip(*np.percentile(samples, [16, 50, 84],
                                                    axis=0)))

    print('MCMC with uncertainties:', 
        "{0:.3f}".format(m_mcmc[0] * 100), 
        '+',
        "{0:.3f}".format(m_mcmc[1] * 100),
        '-',
        "{0:.3f}".format(m_mcmc[2] * 100))


# pg
_ = np.genfromtxt('pg_diff-mag_uncertainty.csv', unpack=True, skip_header=1, delimiter=',')
x_pg = _[0]
y_pg = _[1]
yerr_pg = _[2]
print('pg data n=', np.size(x_pg))
make_regressions(x_pg, y_pg, yerr_pg)

# pv
_ = np.genfromtxt('pv_diff-mag_uncertainty.csv', unpack=True, skip_header=1, delimiter=',')
x_pv = _[0]
y_pv = _[1]
yerr_pv = _[2]
print('pv data n=', np.size(x_pv))
make_regressions(x_pv, y_pv, yerr_pv)

# combined pg pv
x_combined = np.concatenate((x_pg, x_pv))
y_combined = np.concatenate((y_pg, y_pv))
yerr_combined = np.concatenate((yerr_pg, yerr_pv))
print('pg pvv data combined n=', np.size(x_combined))
make_regressions(x_combined, y_combined, yerr_combined)
