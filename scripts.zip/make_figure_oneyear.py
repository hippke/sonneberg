import numpy
import matplotlib.pyplot as plt

path = 'I:/D/Research/KIC8462852 comet/Sonneberg/data_release_v2/'
path = ''
file = 'pg_diff-mag_uncertainty.csv'
_ = numpy.genfromtxt(path + file, unpack=True, skip_header=1, delimiter=',')
x = _[0]
y = _[1]
yerr = _[2]

fig, ax1 = plt.subplots(1, 1, figsize=[8, 5], sharex=False, sharey=False)
ax1.plot((1964, 1965), (0, 0), 'k-')
ax1.tick_params(direction='out')
ax1.errorbar(x, y, yerr=yerr, fmt=".k", linewidth=2, capthick=2, color='blue')
ax1.annotate('Sonneberg pg', xy=(1964.01, -0.53))
ax1.set_xlim(1964.0, 1965.0)
ax1.set_ylim(-0.6, +0.6)
ax1.set_xlabel('Year', fontweight='bold')
ax1.set_ylabel('differential magnitude', fontweight='bold')
fig.tight_layout()
plt.gca().invert_yaxis()
ax1.get_xaxis().get_major_formatter().set_useOffset(False)
fig.savefig(path + 'fig_oneyear.pdf', bbox_inches='tight')
plt.show()
