import numpy
import matplotlib.pyplot as plt


path = 'I:/D/Research/KIC8462852 comet/Sonneberg/data_release_v2/'
path = ''
file = 'cadence.csv'
data = numpy.genfromtxt(path + file)
data = data / 60
bins = numpy.arange(start=0, stop=100, step=10)
n, bins, patches = plt.hist(data, bins=bins, facecolor='blue', alpha=0.75)
plt.xlabel('Exposure time (minutes)', fontweight='bold')
plt.ylabel('Number of plates', fontweight='bold')
plt.grid(True)
plt.savefig(path + 'fig_histo_exposuretime.pdf', bbox_inches='tight')
plt.show()
