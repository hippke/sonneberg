import numpy
import matplotlib.pyplot as plt


path = 'I:/D/Research/KIC8462852 comet/Sonneberg/data_release_v2/'
path = ''
file = 'time_between_obs.csv'
data = numpy.genfromtxt(path + file)  # years
data = data * 365.25  # days
bins = numpy.arange(start = 0, stop = 1000, step = 1)
n, bins, patches = plt.hist(data, bins=bins, facecolor='blue', alpha=0.75)
plt.xlabel('Time between observations (days)', fontweight='bold')
plt.ylabel('Number of plates', fontweight='bold')
ax = plt.axes()
ax.set_xscale("log")
ax.set_xlim([1, 365])
ax.set_ylim([0, 180])
plt.grid(True)
plt.savefig(path + 'fig_histo_time_between_obs.pdf', bbox_inches = 'tight')
plt.show()
